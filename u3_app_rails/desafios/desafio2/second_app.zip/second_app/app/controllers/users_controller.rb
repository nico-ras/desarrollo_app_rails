class UsersController < ApplicationController
  def login
  end
end
