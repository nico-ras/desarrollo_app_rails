class PagesController < ApplicationController
  def one
  end

  def two
  end
  
  def three
  end
end
