class Story < ApplicationRecord

    belongs_to :user
end
