class Pet < ApplicationRecord
    belongs_to :client
    has_many :histories, dependent: :destroy

    def checkups
       histories.count
    end  
    
    def averange_weight
        histories.sum(:weight) / checkups  #histories.pluck(weight).sum 

    end
    
    def averange_height
        histories.sum(:height) / checkups
    end   

    def max_weight
        histories.maximum(:weight) ##histories.pluck(weight).max 
    end  
    
    def max_height
        histories.maximum(:height)
    end

    def last_weight
        histories.last[:weight] #histories.pluck(weight).last 
    end
    def last_height
        histories.last[:height]
    end      
end
