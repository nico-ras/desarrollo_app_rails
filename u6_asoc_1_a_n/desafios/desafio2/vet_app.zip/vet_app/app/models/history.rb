class History < ApplicationRecord
  belongs_to :pet
end
