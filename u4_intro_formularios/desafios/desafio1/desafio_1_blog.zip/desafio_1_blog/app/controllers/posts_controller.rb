class PostsController < ApplicationController
  http_basic_authenticate_with name: "tunombre", password: "tupassword", only:
:dashboard
  
  
  def index
    @articles = Article.all
  end

  def create
    @article = Article.create(title: params[:title], created_at: :created_at , image: params[:image], content: params[:content])
  end  

  def dashboard
    
  end
end
