class UserRequest < ApplicationRecord
end
