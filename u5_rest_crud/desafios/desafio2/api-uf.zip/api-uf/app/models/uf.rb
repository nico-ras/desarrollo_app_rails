class Uf < ApplicationRecord
    validates :value, :date, presence: true
end
